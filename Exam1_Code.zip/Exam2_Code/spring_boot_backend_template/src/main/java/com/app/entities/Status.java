package com.app.entities;

public enum Status {
    OPEN, IN_PROGRESS, CLOSED
}
