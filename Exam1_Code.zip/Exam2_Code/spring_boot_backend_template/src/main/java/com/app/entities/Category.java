package com.app.entities;

public enum Category {
    SIM, CALLING, BROADBAND
}
