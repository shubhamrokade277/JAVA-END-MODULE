package com.app.service;

import com.app.dto.TicketDTO;
import com.app.entities.Ticket;

import java.util.List;

public interface TicketService {
    Ticket createTicket(TicketDTO ticketDTO);
    Ticket updateTicket(Long id, TicketDTO ticketDTO);
    List<Ticket> getAllTickets();
    Ticket getTicketById(Long id);
}
