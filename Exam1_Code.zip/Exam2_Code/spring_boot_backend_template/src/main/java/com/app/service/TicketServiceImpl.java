package com.app.service;

import com.app.dto.TicketDTO;
import com.app.entities.Ticket;
import com.app.exception.ResourceNotFoundException;
import com.app.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class TicketServiceImpl implements TicketService {

    @Autowired
    private TicketRepository ticketRepository;

    @Override
    public Ticket createTicket(TicketDTO ticketDTO) {
        Ticket ticket = new Ticket();
        ticket.setPhoneNumber(ticketDTO.getPhoneNumber());
        ticket.setCategory(ticketDTO.getCategory());
        ticket.setIssueDetails(ticketDTO.getIssueDetails());
        ticket.setStatus(ticketDTO.getStatus());
        ticket.setCreateDateTime(LocalDateTime.now());
        return ticketRepository.save(ticket);
    }

    @Override
    public Ticket updateTicket(Long id, TicketDTO ticketDTO) {
        Ticket ticket = ticketRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ticket not found with id: " + id));
        ticket.setStatus(ticketDTO.getStatus());
        ticket.setResolution(ticketDTO.getResolution());
        ticket.setResolutionDateTime(ticketDTO.getResolutionDateTime());
        return ticketRepository.save(ticket);
    }

    @Override
    public List<Ticket> getAllTickets() {
        return ticketRepository.findAll();
    }

    @Override
    public Ticket getTicketById(Long id) {
        return ticketRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ticket not found with id: " + id));
    }
}
