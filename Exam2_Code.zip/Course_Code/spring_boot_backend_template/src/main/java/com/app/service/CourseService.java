package com.app.service;

import java.util.List;

import com.app.dto.CourseDTO;
import com.app.entities.Course;

public interface CourseService {

    Course addCourse(CourseDTO courseDTO);

    Course updateCourse(Long courseId, CourseDTO courseDTO);

    List<Course> getCoursesForMonth(int year, int month);

    List<Course> getCoursesByName(String name);
}
