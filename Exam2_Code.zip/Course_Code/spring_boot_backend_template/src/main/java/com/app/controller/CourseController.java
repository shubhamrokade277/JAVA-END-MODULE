package com.app.controller;

import com.app.dto.CourseDTO;
import com.app.entities.Course;
import com.app.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @PostMapping
    public ResponseEntity<Course> addCourse(@RequestBody CourseDTO courseDTO) {
        Course createdCourse = courseService.addCourse(courseDTO);
        return new ResponseEntity<>(createdCourse, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Course> updateCourse(
            @PathVariable("id") Long courseId,
            @RequestBody CourseDTO courseDTO) {
        Course updatedCourse = courseService.updateCourse(courseId, courseDTO);
        return new ResponseEntity<>(updatedCourse, HttpStatus.OK);
    }

    @GetMapping("/month/{year}/{month}")
    public ResponseEntity<List<Course>> getCoursesForMonth(
            @PathVariable("year") int year,
            @PathVariable("month") int month) {
        List<Course> courses = courseService.getCoursesForMonth(year, month);
        return new ResponseEntity<>(courses, HttpStatus.OK);
    }

    @GetMapping("/name/{name}")
    public ResponseEntity<List<Course>> getCoursesByName(
            @PathVariable("name") String name) {
        List<Course> courses = courseService.getCoursesByName(name);
        return new ResponseEntity<>(courses, HttpStatus.OK);
    }
}