package com.app.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dto.CourseDTO;
import com.app.entities.Course;
import com.app.exception.CourseNotFoundException;
import com.app.repository.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseRepository courseRepository;

    @Override
    public Course addCourse(CourseDTO courseDTO) {
        Course course = new Course();
        BeanUtils.copyProperties(courseDTO, course);
        course.setUpdateDateTime(LocalDateTime.now());
        return courseRepository.save(course);
    }

    @Override
    public Course updateCourse(Long courseId, CourseDTO courseDTO) {
        Optional<Course> optionalCourse = courseRepository.findById(courseId);
        if (optionalCourse.isPresent()) {
            Course existingCourse = optionalCourse.get();
            BeanUtils.copyProperties(courseDTO, existingCourse);
            existingCourse.setUpdateDateTime(LocalDateTime.now());
            return courseRepository.save(existingCourse);
        } else {
            throw new CourseNotFoundException("Course not found with id: " + courseId);
        }
    }

    @Override
    public List<Course> getCoursesForMonth(int year, int month) {
        LocalDateTime startOfMonth = LocalDateTime.of(year, month, 1, 0, 0);
        LocalDateTime endOfMonth = startOfMonth.plusMonths(1).minusSeconds(1);
        return courseRepository.findByStartDateBetween(startOfMonth, endOfMonth);
    }

    @Override
    public List<Course> getCoursesByName(String name) {
        return courseRepository.findByNameContainingIgnoreCase(name);
    }
}
