package com.app.entities;

public enum CourseCategory {
	JAVA_BEGINNER, JAVA_ADVANCED
}
