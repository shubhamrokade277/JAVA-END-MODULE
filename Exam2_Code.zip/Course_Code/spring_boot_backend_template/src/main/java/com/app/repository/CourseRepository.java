package com.app.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.Course;

public interface CourseRepository extends JpaRepository<Course, Long> {

    List<Course> findByStartDateBetween(LocalDateTime startOfMonth, LocalDateTime endOfMonth);

    List<Course> findByNameContainingIgnoreCase(String name);
}