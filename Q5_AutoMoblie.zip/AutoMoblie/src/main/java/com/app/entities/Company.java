package com.app.entities;

public enum Company {
    HERO, HONDA, BAJAJ
}
