package com.hotel.entities;

public enum Type {

	SINGLE,DOUBLE,SUITE
}
